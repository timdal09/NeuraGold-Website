from flask import Flask, render_template_string

app = Flask(__name__)

html_content = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NeuraGold - The Future of AI & Gold</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #0a0a0a;
            color: white;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: #1a1a1a;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(255, 215, 0, 0.5);
        }
        h1 {
            color: gold;
        }
        .btn {
            background: gold;
            color: black;
            padding: 10px 20px;
            text-decoration: none;
            font-size: 18px;
            font-weight: bold;
            border-radius: 5px;
            display: inline-block;
            margin-top: 10px;
        }
        .btn:hover {
            background: #ffd700;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚀 Welcome to NeuraGold! 🚀</h1>
        <p><strong>The Future of AI Meets Digital Gold</strong></p>
        <img src="static/NeuraGold_128x128.png" alt="NeuraGold Logo">
        <h2>Why Buy NeuraGold?</h2>
        <ul>
            <li>💰 A unique meme coin backed by AI and gold-inspired design</li>
            <li>📈 High potential for viral success and community-driven growth</li>
            <li>🔗 Built on secure blockchain technology</li>
            <li>🚀 Be an early adopter and ride the wave!</li>
        </ul>
        <h2>Where to Buy?</h2>
        <p>NeuraGold is available on <strong>Raydium</strong>. Click below to purchase:</p>
        <a href="#" class="btn">Buy NeuraGold Now</a>
        <h2>The Vision</h2>
        <p>NeuraGold is not just another meme coin—it's a movement combining AI, blockchain, and digital value to create something truly special. Join us and be part of the future! 🚀</p>
    </div>
</body>
</html>
'''

@app.route('/')
def home():
    return render_template_string(html_content)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
